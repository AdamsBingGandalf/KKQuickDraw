//
//  AppDelegate.h
//  KKQuickDraw
//
//  Created by Hansen on 5/17/21.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

